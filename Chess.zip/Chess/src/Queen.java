
public class Queen extends Piece
{
    public Queen(int rank, int file, String filename)
    {
        super(rank, file, filename);
    }
}
