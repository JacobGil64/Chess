import javax.swing.*;
import java.io.File;

public class Button
{
    private int rank;
    private int file;
    private int scale;

    private String filename;
    private JButton button;

    private int mouseX;
    private int mouseY;

    public Button(int rank, int file, int scale, String filename)
    {
        this.rank = rank;
        this.file = file;

        String src = new File("").getAbsolutePath() + "/src/";
        ImageIcon dirLocation = new ImageIcon(src + filename);
        button = new JButton(dirLocation); // connect img to objects img field

        button.setBounds(file * scale - scale, (9 - rank) * scale - scale, scale, scale);
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
    }

    public int getRank()
    {
        return rank;
    }

    public int getFile()
    {
        return file;
    }

    public JButton getImg()
    {
        return button;
    }

    public void setMouseX(int mouseX)
    {
        this.mouseX = mouseX;
    }
    public void setMousey(int mouseY)
    {
        this.mouseY = mouseY;
    }
}
