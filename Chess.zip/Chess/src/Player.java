
public class Player
{
    private double timer;
    private double timeRemaining;

    public Player()
    {

    }

    public double
    getTimer()
    {
        return timer;
    }

    public void setTimer(double timer)
    {
        this.timer = timer;
    }

    public double getTimeRemaining()
    {
        return timeRemaining;
    }

    public void setTimeRemaining(double timeRemaining)
    {
        this.timeRemaining = timeRemaining;
    }

}
