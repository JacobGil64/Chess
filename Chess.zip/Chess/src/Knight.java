
public class Knight extends Piece
{
    public Knight(int rank, int file, String filename)
    {
        super(rank, file, filename);
    }
}
