
public class Pawn extends Piece
{
    public Pawn(int rank, int file, String filename)
    {
        super(rank, file, filename);
    }
}
