import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Piece
{
    private int rank;
    private int file;
    private int scale = 100; // width and height of each square on board

    private boolean validMove;
    private boolean alive;

    private String filename;
    private JLabel img;

    public Piece(int rank, int file, String filename)
    {
        this.rank = rank;
        this.file = file;
        alive = true;

        String src = new File("").getAbsolutePath() + "/src/";
        ImageIcon dirLocation = new ImageIcon(src + filename);
        img = new JLabel(dirLocation); // connect img to objects img field

        img.setBounds(file * scale - scale, (9 - rank) * scale - scale, scale, scale);
    }

    public int getRank()
    {
        return rank;
    }

    public int getFile()
    {
        return file;
    }

    public boolean getAlive()
    {
        return alive;
    }

    public JLabel getImg()
    {
        return img;
    }

    public void setBounds(int x, int y, int w, int h)
    {
        img.setBounds(x, y, w, h);
        file = x / scale;
        rank = (9 - y) / scale;
    }

//    public void move()
//    {
//        // Insert and position and update .setImg()
//        if(validMove(f1, r1,f2, r2))
//        {
//            // allow move
//        }
//    }
//
//    public boolean validMove(int f1, int r1, int f2, int r2)
//    {
//        return true;
//    }
}
