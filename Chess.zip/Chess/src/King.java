
public class King extends Piece
{
    public King(int rank, int file, String filename)
    {
        super(rank, file, filename);
    }



}
