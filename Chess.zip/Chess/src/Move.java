public class Move
{
    private int rank;
    private int file;
    private int scale;

    private String filename;

    private int mouseX;
    private int mouseY;

    public Move()
    {
        mouseX = 1;
        mouseY = 1;
    }

    public void setMouseX(int mouseX)
    {
        this.mouseX = mouseX;
    }

    public void setMouseY(int mouseY)
    {
        this.mouseY = mouseY;
    }

    public int getMouseX()
    {
        return mouseX;
    }

    public int getMouseY()
    {
        return mouseY;
    }

    public int getRank()
    {
        if (mouseY <= 831)
        {
            rank = (((mouseY + 100 - 31)) % 10) ;
        }
        return rank;
    }

    public int getFile()
    {
        if (mouseX <= 800)

        {
            file = (((mouseX + 100)) % 10) % 10;
        }
        return file;
    }
}