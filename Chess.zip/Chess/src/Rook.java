
public class Rook extends Piece
{
    public Rook(int rank, int file, String filename)
    {
        super(rank, file, filename);
    }
}
