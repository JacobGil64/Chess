import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;

public class Driver extends JPanel implements ActionListener, KeyListener, MouseListener, MouseMotionListener
{
    // Window Size
    private final int windowWidth = 1200;
    private final int windowHeight = 838;

    // Containers for Pieces
    private ArrayList<Piece> p1Pieces = new ArrayList<Piece>();
    private ArrayList<Piece> p2Pieces = new ArrayList<Piece>();
    private Font font = new Font("Courier New", 1, 25);

    Move move;

    private void update()
    {
        move.setMouseX((int) MouseInfo.getPointerInfo().getLocation().getX());
        move.setMouseY((int) MouseInfo.getPointerInfo().getLocation().getY());
    }

    @Override
    public void actionPerformed(ActionEvent arg0)
    {
        update();

    }

    public static void main(String[] arg)
    {
        Driver d = new Driver();
    }

    private Driver()
    {
        // Keep at Top
        JFrame f = new JFrame();
        f.setTitle("Chess");
        f.setSize(windowWidth, windowHeight);
        f.setResizable(false);
        f.addKeyListener(this);
        f.addMouseListener(this);

        // Instantiating Players
        Player p1 = new Player();
        Player p2 = new Player();

        move = new Move();

        // Instantiating Buttons
        Button f1r1 = new Button(1, 1, 100, "");
        Button f2r1 = new Button(1, 2, 100, "");
        Button f3r1 = new Button(1, 3, 100, "");
        Button f4r1 = new Button(1, 4, 100, "");
        Button f5r1 = new Button(1, 5, 100, "");
        Button f6r1 = new Button(1, 6, 100, "");
        Button f7r1 = new Button(1, 7, 100, "");
        Button f8r1 = new Button(1, 8, 100, "");


        // Instantiating Pieces
        King p1King = new King(1, 5, "kingL.png"); // figure out x , y in array
        King p2King = new King(8, 5, "kingD.png");
        Queen p1Queen = new Queen(1, 4, "queenL.png");
        Queen p2Queen = new Queen(8, 4, "queenD.png");
        Bishop p1Bishop6 = new Bishop(1, 6, "bishopL.png");
        Bishop p1Bishop3 = new Bishop(1, 3, "bishopL.png");
        Bishop p2Bishop3 = new Bishop(8, 3, "bishopD.png");
        Bishop p2Bishop6 = new Bishop(8, 6, "bishopD.png");
        Knight p1Knight2 = new Knight(1, 2, "knightL.png");
        Knight p1Knight7 = new Knight(1, 7, "knightL.png");
        Knight p2Knight7 = new Knight(8, 7, "knightD.png");
        Knight p2Knight2 = new Knight(8, 2, "knightD.png");
        Rook p1Rook8 = new Rook(1, 8, "rookL.png");
        Rook p1Rook1 = new Rook(1, 1, "rookL.png");
        Rook p2Rook1 = new Rook(8, 1, "rookD.png");
        Rook p2Rook8 = new Rook(8, 8, "rookD.png");
        Pawn p1Pawn1 = new Pawn(2, 1, "pawnL.png");
        Pawn p1Pawn2 = new Pawn(2, 2, "pawnL.png");
        Pawn p1Pawn3 = new Pawn(2, 3, "pawnL.png");
        Pawn p1Pawn4 = new Pawn(2, 4, "pawnL.png");
        Pawn p1Pawn5 = new Pawn(2, 5, "pawnL.png");
        Pawn p1Pawn6 = new Pawn(2, 6, "pawnL.png");
        Pawn p1Pawn7 = new Pawn(2, 7, "pawnL.png");
        Pawn p1Pawn8 = new Pawn(2, 8, "pawnL.png");
        Pawn p2Pawn1 = new Pawn(7, 1, "pawnD.png");
        Pawn p2Pawn2 = new Pawn(7, 2, "pawnD.png");
        Pawn p2Pawn3 = new Pawn(7, 3, "pawnD.png");
        Pawn p2Pawn4 = new Pawn(7, 4, "pawnD.png");
        Pawn p2Pawn5 = new Pawn(7, 5, "pawnD.png");
        Pawn p2Pawn6 = new Pawn(7, 6, "pawnD.png");
        Pawn p2Pawn7 = new Pawn(7, 7, "pawnD.png");
        Pawn p2Pawn8 = new Pawn(7, 8, "pawnD.png");

        // Adding Pieces to Window
        f.add(p1King.getImg());
        f.add(p2King.getImg());
        f.add(p1Queen.getImg());
        f.add(p2Queen.getImg());
        f.add(p1Bishop6.getImg());
        f.add(p1Bishop3.getImg());
        f.add(p2Bishop3.getImg());
        f.add(p2Bishop6.getImg());
        f.add(p1Knight7.getImg());
        f.add(p1Knight2.getImg());
        f.add(p2Knight2.getImg());
        f.add(p2Knight7.getImg());
        f.add(p1Rook8.getImg());
        f.add(p1Rook1.getImg());
        f.add(p2Rook1.getImg());
        f.add(p2Rook8.getImg());
        f.add(p1Pawn1.getImg());
        f.add(p1Pawn2.getImg());
        f.add(p1Pawn3.getImg());
        f.add(p1Pawn4.getImg());
        f.add(p1Pawn5.getImg());
        f.add(p1Pawn6.getImg());
        f.add(p1Pawn7.getImg());
        f.add(p1Pawn8.getImg());
        f.add(p2Pawn1.getImg());
        f.add(p2Pawn2.getImg());
        f.add(p2Pawn3.getImg());
        f.add(p2Pawn4.getImg());
        f.add(p2Pawn5.getImg());
        f.add(p2Pawn6.getImg());
        f.add(p2Pawn7.getImg());
        f.add(p2Pawn8.getImg());

        // Adding Buttons to Window
        f.add(f1r1.getImg());
        f.add(f2r1.getImg());
        f.add(f3r1.getImg());
        f.add(f4r1.getImg());
        f.add(f5r1.getImg());
        f.add(f6r1.getImg());
        f.add(f7r1.getImg());
        f.add(f8r1.getImg());

        // Background
        String backgroundFile = "chessBoard.png";
        String src = new File("").getAbsolutePath() + "/src/"; // Path to image setup
        ImageIcon dirLocation = new ImageIcon(src + backgroundFile);
        JLabel background = new JLabel(dirLocation);
        background.setBounds(0, 0, windowWidth, windowHeight);
        f.add(background);

        // Keep at Bottom
        f.add(this);
        t = new Timer(17, this);
        t.start();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    }

    Timer t;

    @Override
    public void keyPressed(KeyEvent e)
    {
    }

    @Override
    public void keyReleased(KeyEvent e)
    {
    }

    @Override
    public void mouseClicked(MouseEvent e)
    {
        System.out.println(move.getFile());
        System.out.println(move.getRank());
    }

    @Override
    public void mouseDragged(MouseEvent arg0)
    {
    }

    @Override
    public void mouseMoved(MouseEvent arg0)
    {

    }

    @Override
    public void mouseEntered(MouseEvent arg0)
    {
    }

    @Override
    public void mouseExited(MouseEvent arg0)
    {
    }

    @Override
    public void mousePressed(MouseEvent arg0)
    {
    }

    @Override
    public void mouseReleased(MouseEvent arg0)
    {
    }

    @Override
    public void keyTyped(KeyEvent e)
    {
    }
}
