
public class Bishop extends Piece
{
    public Bishop(int rank, int file, String filename)
    {
        super(rank, file, filename);
    }
}
